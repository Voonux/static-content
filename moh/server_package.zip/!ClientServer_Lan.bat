@echo off

:: ===========================
:: CONFIGURATION
:: ===========================

:: The level that game will be started with (not required)
set STARTUP_LEVEL=Levels/MP_01

:: The playlist the client server will use for choosing next levels
:: Available playlists: CombatMission, TeamAssault, SectorControl, ObjectiveRaid, CleanSweep, KingOfTheHill, Hardcore, HardcoreCleanSweep, HardcoreKingOfTheHill
set PLAYLIST=CombatMission

:: The port that the game server will be hosted on
:: By default game server uses 1003 port
set SERVER_PORT=1003

:: Set your desired player name (if left empty, then expect player names like Player, Player1, Player2, etc.)
set PLAYER_NAME=Player

:: Set your desired clan tag (leave empty if you don’t want one)
set CLAN_TAG=

:: Set to "true" to start game in spectator mode
set SPECTATOR=false

:: Chat admin password
:: By default client server players are already chat administrators. You may specify password if you wish to allow other people to be chat administrators.
:: Other administrators will need to specify -chatAdminPassword option when launching game or authenticate using /auth chat command
set CHAT_ADMIN_PASSWORD=

:: ===========================
:: DO NOT TOUCH ANYTHING BELOW
:: ===========================

set ARGS=

if not "%STARTUP_LEVEL%"=="" set ARGS=%ARGS% -level "%STARTUP_LEVEL%"
if not "%PLAYLIST%"=="" set ARGS=%ARGS% -playlist "%PLAYLIST%"
if not "%SERVER_PORT%"=="" set ARGS=%ARGS% -serverPort %SERVER_PORT%
if not "%CLAN_TAG%"=="" set ARGS=%ARGS% -clanTag "%CLAN_TAG%"
if not "%PLAYER_NAME%"=="" set ARGS=%ARGS% -playerName "%PLAYER_NAME%"
if /I "%SPECTATOR%"=="true" set ARGS=%ARGS% -spectator
if not "%CHAT_ADMIN_PASSWORD%"=="" set ARGS=%ARGS% -chatAdminPassword "%CHAT_ADMIN_PASSWORD%"


start MoHMPGame.exe %ARGS%