@echo off

:: ===========================
:: CONFIGURATION
:: ===========================

:: The directory where server instance data will be read and stored
:: It must be a full path to directory which must exist
:: If not specified, game root directory will be used instead (not recommended)
set INSTANCE_DIRECTORY=%~dp0Instance

:: Server name
:: The server name is chosen (in order):
:: 1. AdminScripts/startup.txt defined server name
:: 2. Defined server name here
:: 3. Computer name
set SERVER_NAME=Example Server

:: The port that the game server will be hosted on
:: By default server uses 1003 port
set SERVER_PORT=1003

:: Chat admin password
:: Administrators will need to authenticate using /auth chat command
set CHAT_ADMIN_PASSWORD=

:: Defines whether game server will also host remote administration server.
:: If not specified, the remote administration server will be enabled.
set REMOTE_ADMIN_ENABLED=true

:: Remote admin password to use when authenticating to remote administration server
:: If it is not specified, you will not be able to login.
set REMOTE_ADMIN_PASSWORD=

:: The address the server will listen on for remote admin connections
:: If not specified, then localhost:48888 is used by default
set REMOTE_ADMIN_PORT=0.0.0.0:48888

:: The level that server will be started with
:: If left empty, then server will start with the first level it gets from map sequencer (admin controlled or playlist one)
set STARTUP_LEVEL=

:: This flag defines what kind of map sequencer the server will use.
:: If set to true, then server will use admin controlled map sequencer (that you can change using remote administration interface)
:: If set to false, then server will use playlist map sequencer (server will randomly load maps from a predefined playlist)
set USE_MAPLIST=true

:: The playlist that server will use for choosing next levels (if playlist map sequencer is used)
:: If admin controlled map sequencer is used then this option can be simply ignored.
:: If playlist map sequencer is used and this option is left empty: random playlist will be used (if startup level is specified then random playlist that contains the startup level)
:: Available playlists: CombatMission, TeamAssault, SectorControl, ObjectiveRaid, CleanSweep, KingOfTheHill, Hardcore, HardcoreCleanSweep, HardcoreKingOfTheHill
set PLAYLIST=

:: ===========================
:: DO NOT TOUCH ANYTHING BELOW
:: ===========================

set ARGS= 

if not "%INSTANCE_DIRECTORY%"=="" set ARGS=%ARGS% -serverInstancePath "%INSTANCE_DIRECTORY%"
if not "%SERVER_NAME%"=="" set ARGS=%ARGS% -name "%SERVER_NAME%"
if not "%STARTUP_LEVEL%"=="" set ARGS=%ARGS% -level "%STARTUP_LEVEL%"
if not "%CHAT_ADMIN_PASSWORD%"=="" set ARGS=%ARGS% -chatAdminPassword "%CHAT_ADMIN_PASSWORD%"
if not "%REMOTE_ADMIN_ENABLED%"=="" set ARGS=%ARGS% -remoteAdminEnabled %REMOTE_ADMIN_ENABLED%
if not "%REMOTE_ADMIN_PASSWORD%"=="" set ARGS=%ARGS% -remoteAdminPassword "%REMOTE_ADMIN_PASSWORD%"
if not "%REMOTE_ADMIN_PORT%"=="" set ARGS=%ARGS% -remoteAdminPort %REMOTE_ADMIN_PORT%
if not "%USE_MAPLIST%"=="" set ARGS=%ARGS% -Server.MapList %USE_MAPLIST%
if not "%PLAYLIST%"=="" set ARGS=%ARGS% -Server.Playlist "%PLAYLIST%"

if "%SERVER_PORT%"=="" set SERVER_PORT=1003
set ARGS=%ARGS% -Network.ServerPort %SERVER_PORT%

start MoHMPGame.exe -server %ARGS% -Server.Backend BackendType_Blaze