@echo off

:: ===========================
:: CONFIGURATION
:: ===========================

:: REQUIRED! Set server address which is in the form <ip>:<port>
set SERVER_IP=127.0.0.1:1003

:: Set your desired player name (if left empty, then expect player names like Player1, Player2, etc.)
set PLAYER_NAME=Player

:: Set your desired clan tag (leave empty if you don’t want one)
set CLAN_TAG=

:: Set to "true" to start game in spectator mode (server may deny spectating in which case you will join as soldier instead)
set SPECTATOR=false

:: Chat admin password
:: If you have been given chat administration password then you can specify it here or you can authenticate using /auth chat command
set CHAT_ADMIN_PASSWORD=

:: ===========================
:: DO NOT TOUCH ANYTHING BELOW
:: ===========================

if "%SERVER_IP%"=="" (
    echo [ERROR] SERVER_IP is not specified!
    echo Press any key to close the console...
    pause >nul
    exit /b 1
)

set ARGS= -serverIp "%SERVER_IP%"

if not "%CLAN_TAG%"=="" set ARGS=%ARGS% -clanTag "%CLAN_TAG%"
if not "%PLAYER_NAME%"=="" set ARGS=%ARGS% -playerName "%PLAYER_NAME%"
if /I "%SPECTATOR%"=="true" set ARGS=%ARGS% -spectator
if not "%CHAT_ADMIN_PASSWORD%"=="" set ARGS=%ARGS% -chatAdminPassword "%CHAT_ADMIN_PASSWORD%"

start MoHMPGame.exe %ARGS%